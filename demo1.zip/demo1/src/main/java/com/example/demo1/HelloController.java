 package com.example.demo1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.net.URL;
import java.util.ResourceBundle;

 public class HelloController implements Initializable {
    @FXML
    private TextField imieField;

    @FXML
    private TextField nazwiskoField;

    @FXML
    private RadioButton mRadio;

    @FXML
    private RadioButton kRadio;

     @FXML
     private Spinner<Integer> wiekSpinner;

     @FXML
     private ChoiceBox<String> profilChoice;

     @FXML
     private CheckBox nCheck;

     @FXML
     private TextField emailField;

     @FXML
     private TextField passField;

     private String[] majors = {"Technik Teleinformatyk", "Technik Programista", "Technik Mechatronik", "Technik Elektronik", "Technik Automatyk"};
     String imie;
     String nazwisko;
     String sxx;
     Integer wiek;
     String profil;
     String niepel;
     String email = emailField.getText();

     Boolean ERROR = false;

     @Override
     public void initialize(URL url, ResourceBundle resourceBundle) {
        profilChoice.getItems().addAll(majors);
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(14,20);
        valueFactory.setValue(1);
        wiekSpinner.setValueFactory(valueFactory);
     }

     public void setInfo(){
        imie = imieField.getText();
        nazwisko = nazwiskoField.getText();
        if (mRadio.isSelected()){
            sxx = "Mężczyzna";
        } else if (kRadio.isSelected()) {
            sxx = "Kobieta";
        }
        wiek = wiekSpinner.getValue();
        profil = profilChoice.getValue();
        if (nCheck.isSelected()){
            niepel = "Wymagam udogodnień";
        }else {
            niepel = "";
       }
     }

     public void errorCheck(){
         if (imie == null || nazwisko == null || sxx == null || wiek == null || profil == null || email == null || passField.getText() == null){
             ERROR = true;
             Alert alert = new Alert(AlertType.INFORMATION);
             alert.setTitle("Information");
             alert.setContentText("Proszę wypełnić wszystkie pola");
             alert.showAndWait();
         }else{
             ERROR = false;
         }
     }

     public void showInfo(String msg){
         Alert alert = new Alert(AlertType.INFORMATION);
         alert.setTitle("Information");
         alert.setContentText(msg);
         alert.showAndWait();
     }

     public void submit(){
         setInfo();
         errorCheck();
         if (!ERROR) {
             showInfo("Imię: " + imie + "\nNazwisko: " + nazwisko + "\nPłeć: " + sxx + "\nWiek: " + wiek + "\nProfil: " + profil + "\n" + niepel);
         }
     }

 }
